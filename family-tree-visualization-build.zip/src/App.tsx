import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ZoomIn, 
  ZoomOut, 
  Plus, 
  Trash2, 
  Edit3, 
  User, 
  Heart, 
  Calendar, 
  MapPin, 
  Briefcase,
  X,
  Search,
  Download,
  Upload,
  RotateCcw,
  Save,
  Maximize2,
  Minimize2,
  Users,
  Share2
} from 'lucide-react';
import * as htmlToImage from 'html-to-image';
import { Person, NodePosition } from '@/types/family';
import { initialFamilyData } from '@/data/familyData';

// Constants for layout
const NODE_WIDTH = 220;
const NODE_HEIGHT = 100;
const VERTICAL_SPACING = 220; // Increased for more space between generations
const SPOUSE_SPACING = 60; // Distance between spouses (increased to prevent overlap)
const SIBLING_SPACING = 400; // Distance between siblings (increased for spouse pairs)
// Utility functions
const formatDate = (dateStr: string | undefined): string => {
  if (!dateStr) return 'Unknown';
  const date = new Date(dateStr);
  return date.toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'short', 
    day: 'numeric' 
  });
};

const calculateAge = (birthDate: string, deathDate?: string): number => {
  const birth = new Date(birthDate);
  const end = deathDate ? new Date(deathDate) : new Date();
  let age = end.getFullYear() - birth.getFullYear();
  const monthDiff = end.getMonth() - birth.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && end.getDate() < birth.getDate())) {
    age--;
  }
  return age;
};

// Layout algorithm - Fixed version with proper spouse positioning
const calculateLayout = (people: Person[]): Map<string, NodePosition> => {
  const positions = new Map<string, NodePosition>();
  const levels = new Map<string, number>();
  const subtreeWidths = new Map<string, number>();
  const familyGroups = new Map<string, string>(); // Maps person to their family group id
  
  // Helper: Get family unit id (the person with smaller id in couple)
  const getFamilyId = (person: Person): string => {
    if (!person.spouseId) return person.id;
    return person.id < person.spouseId ? person.id : person.spouseId;
  };
  
  // Helper: Calculate family width (person + spouse)
  const getFamilyWidth = (person: Person): number => {
    return person.spouseId ? NODE_WIDTH * 2 + SPOUSE_SPACING : NODE_WIDTH;
  };
  
  // Helper: Calculate subtree width recursively for a family unit
  const calculateSubtreeWidth = (personId: string, visited: Set<string>): number => {
    if (visited.has(personId)) return 0;
    
    const person = people.find(p => p.id === personId);
    if (!person) return 0;
    
    // Mark both spouses as visited
    visited.add(person.id);
    if (person.spouseId) visited.add(person.spouseId);
    
    // Store family group
    const familyId = getFamilyId(person);
    familyGroups.set(person.id, familyId);
    if (person.spouseId) familyGroups.set(person.spouseId, familyId);
    
    if (person.childrenIds.length === 0) {
      // Leaf node
      const width = getFamilyWidth(person);
      subtreeWidths.set(familyId, width);
      return width;
    }
    
    // Calculate total width of all children subtrees
    let childrenWidth = 0;
    const children = person.childrenIds
      .map(id => people.find(p => p.id === id))
      .filter((p): p is Person => !!p);
    
    children.forEach((child, idx) => {
      if (idx > 0) childrenWidth += SIBLING_SPACING;
      const childFamilyId = getFamilyId(child);
      // Only calculate if not already processed
      if (!visited.has(child.id) && !visited.has(child.spouseId || '')) {
        childrenWidth += calculateSubtreeWidth(child.id, visited);
      } else {
        childrenWidth += subtreeWidths.get(childFamilyId) || getFamilyWidth(child);
      }
    });
    
    // Width is max of family unit width or children total width
    const familyWidth = getFamilyWidth(person);
    const totalWidth = Math.max(familyWidth, childrenWidth);
    subtreeWidths.set(familyId, totalWidth);
    return totalWidth;
  };
  
  // Find root nodes (oldest generation, no parents in dataset)
  const findRoots = (): Person[] => {
    return people.filter(p => 
      p.parentIds.length === 0 || 
      p.parentIds.every(id => !people.find(x => x.id === id))
    );
  };
  
  // Calculate levels using BFS
  const calculateLevels = () => {
    const roots = findRoots();
    const queue: Array<{ person: Person; level: number }> = [];
    const visited = new Set<string>();
    
    roots.forEach(root => {
      if (!visited.has(root.id)) {
        visited.add(root.id);
        levels.set(root.id, 0);
        if (root.spouseId) {
          visited.add(root.spouseId);
          levels.set(root.spouseId, 0);
        }
        queue.push({ person: root, level: 0 });
      }
    });
    
    while (queue.length > 0) {
      const { person, level } = queue.shift()!;
      
      // Process children
      person.childrenIds.forEach(childId => {
        const child = people.find(p => p.id === childId);
        if (child && !levels.has(child.id)) {
          levels.set(child.id, level + 1);
          if (child.spouseId) {
            levels.set(child.spouseId, level + 1);
          }
          queue.push({ person: child, level: level + 1 });
        }
      });
    }
  };
  
  // Assign positions using post-order traversal
  const assignPositions = () => {
    const assigned = new Set<string>();
    const rootNodes = findRoots();
    
    // Sort roots by birth year for consistency
    rootNodes.sort((a, b) => new Date(a.birthDate).getTime() - new Date(b.birthDate).getTime());
    
    let currentX = 0;
    
    const positionSubtree = (personId: string, level: number, startX: number): number => {
      if (assigned.has(personId)) return startX;
      
      const person = people.find(p => p.id === personId);
      if (!person) return startX;
      
      const spouse = person.spouseId ? people.find(p => p.id === person.spouseId) : null;
      const familyWidth = getFamilyWidth(person);
      
      let familyCenterX: number;
      
      if (person.childrenIds.length === 0) {
        // Leaf node - position family at startX
        familyCenterX = startX + familyWidth / 2;
      } else {
        // Parent node - center above children
        let childrenStartX = startX;
        let minChildX = Infinity;
        let maxChildX = -Infinity;
        
        // Process children first to determine parent position
        person.childrenIds.forEach((childId, idx) => {
          const child = people.find(p => p.id === childId);
          if (child) {
            if (idx > 0) {
              const prevChild = people.find(p => p.id === person.childrenIds[idx - 1]);
              if (prevChild) {
                const prevFamilyId = getFamilyId(prevChild);
                childrenStartX += (subtreeWidths.get(prevFamilyId) || getFamilyWidth(prevChild));
                childrenStartX += SIBLING_SPACING;
              }
            }
            const childCenterX = positionSubtree(childId, level + 1, childrenStartX);
            minChildX = Math.min(minChildX, childCenterX);
            maxChildX = Math.max(maxChildX, childCenterX);
          }
        });
        
        // Center parent family above children
        familyCenterX = (minChildX + maxChildX) / 2;
        
        // Ensure minimum spacing from startX
        if (familyCenterX - familyWidth / 2 < startX) {
          familyCenterX = startX + familyWidth / 2;
        }
      }
      
      // Position primary person (left side of family unit)
      const primaryPersonX = familyCenterX - familyWidth / 2 + NODE_WIDTH / 2;
      
      positions.set(person.id, {
        x: primaryPersonX,
        y: level * VERTICAL_SPACING,
        person,
        level,
        index: 0
      });
      assigned.add(person.id);
      
      // Position spouse to the right
      if (spouse && !assigned.has(spouse.id)) {
        positions.set(spouse.id, {
          x: primaryPersonX + NODE_WIDTH + SPOUSE_SPACING,
          y: level * VERTICAL_SPACING,
          person: spouse,
          level,
          index: 1
        });
        assigned.add(spouse.id);
      }
      
      return familyCenterX;
    };
    
    // Position each root family
    rootNodes.forEach(root => {
      if (!assigned.has(root.id)) {
        const rootFamilyId = getFamilyId(root);
        const rootSubtreeWidth = subtreeWidths.get(rootFamilyId) || getFamilyWidth(root);
        positionSubtree(root.id, 0, currentX);
        currentX += rootSubtreeWidth + SIBLING_SPACING;
      }
    });
    
    // Center the entire tree
    let minX = Infinity, maxX = -Infinity;
    positions.forEach(pos => {
      minX = Math.min(minX, pos.x - NODE_WIDTH / 2);
      maxX = Math.max(maxX, pos.x + NODE_WIDTH / 2);
    });
    
    const treeCenter = (minX + maxX) / 2;
    positions.forEach(pos => {
      pos.x -= treeCenter;
    });
  };
  
  // Run layout algorithm
  const roots = findRoots();
  const visited = new Set<string>();
  roots.forEach(root => calculateSubtreeWidth(root.id, visited));
  calculateLevels();
  assignPositions();
  
  return positions;
};

// Components
interface ConnectionLinesProps {
  positions: Map<string, NodePosition>;
  selectedPersonId: string | null;
  connectedNodes: Set<string>;
}

const ConnectionLines: React.FC<ConnectionLinesProps> = ({ positions, selectedPersonId, connectedNodes }) => {
  const connections: React.ReactNode[] = [];
  const processedSpouses = new Set<string>();
  
  positions.forEach((pos) => {
    const person = pos.person;
    
    // Spouse connections - draw horizontal line with heart in middle
    if (person.spouseId && positions.has(person.spouseId)) {
      const spouseKey = [person.id, person.spouseId].sort().join('-');
      if (!processedSpouses.has(spouseKey)) {
        processedSpouses.add(spouseKey);
        const spousePos = positions.get(person.spouseId)!;
        
        // Determine left and right positions
        const leftPos = pos.x < spousePos.x ? pos : spousePos;
        const rightPos = pos.x < spousePos.x ? spousePos : pos;
        
        // Calculate connection points from edges of nodes
        const startX = leftPos.x + NODE_WIDTH / 2;  // Right edge of left node
        const endX = rightPos.x - NODE_WIDTH / 2;   // Left edge of right node
        const y = pos.y;
        const midX = (startX + endX) / 2;
        
        const isSpouseHighlighted = selectedPersonId && 
          (connectedNodes.has(person.id) || connectedNodes.has(person.spouseId));
        
        connections.push(
          <g key={`spouse-${spouseKey}`}>
            {/* Horizontal spouse connection */}
            <line
              x1={startX}
              y1={y}
              x2={endX}
              y2={y}
              stroke={isSpouseHighlighted ? '#f59e0b' : '#f472b6'}
              strokeWidth={isSpouseHighlighted ? 5 : 3}
              strokeLinecap="round"
              style={{
                filter: isSpouseHighlighted ? 'drop-shadow(0 0 4px rgba(245, 158, 11, 0.6))' : 'none'
              }}
            />
            {/* Heart in the middle */}
            <g transform={`translate(${midX}, ${y})`}>
              <circle 
                r={isSpouseHighlighted ? 16 : 12} 
                fill={isSpouseHighlighted ? '#fef3c7' : '#fce7f3'} 
                stroke={isSpouseHighlighted ? '#f59e0b' : '#f472b6'} 
                strokeWidth={isSpouseHighlighted ? 3 : 2}
                style={{
                  filter: isSpouseHighlighted ? 'drop-shadow(0 0 6px rgba(245, 158, 11, 0.5))' : 'none'
                }}
              />
              <text 
                textAnchor="middle" 
                dominantBaseline="central" 
                fontSize={isSpouseHighlighted ? 16 : 12} 
                fill={isSpouseHighlighted ? '#f59e0b' : '#f472b6'}
              >
                ♥
              </text>
            </g>
          </g>
        );
      }
    }
    
    // Parent-child connections
    if (person.childrenIds.length > 0) {
      const childPositions = person.childrenIds
        .map(id => positions.get(id))
        .filter((p): p is NodePosition => !!p);
      
      if (childPositions.length > 0) {
        // Find parent's connection point (bottom center)
        const parentY = pos.y + NODE_HEIGHT / 2;
        
        // If person has spouse, calculate center point between them
        let parentX = pos.x;
        if (person.spouseId && positions.has(person.spouseId)) {
          const spousePos = positions.get(person.spouseId)!;
          parentX = (pos.x + spousePos.x) / 2;
        }
        
        // Calculate vertical drop point - add gap from node
        const dropY = parentY + VERTICAL_SPACING / 3;
        
        // Check if this parent-child connection should be highlighted
        const isParentHighlighted = selectedPersonId && connectedNodes.has(person.id);
        
        // Vertical line down from parent center
        connections.push(
          <line
            key={`parent-drop-${person.id}`}
            x1={parentX}
            y1={parentY}
            x2={parentX}
            y2={dropY}
            stroke={isParentHighlighted ? '#f59e0b' : '#64748b'}
            strokeWidth={isParentHighlighted ? 4 : 2}
            strokeLinecap="round"
            style={{
              filter: isParentHighlighted ? 'drop-shadow(0 0 4px rgba(245, 158, 11, 0.6))' : 'none'
            }}
          />
        );
        
        // Horizontal line connecting all children at drop level
        if (childPositions.length > 0) {
          const minChildX = Math.min(...childPositions.map(p => p.x));
          const maxChildX = Math.max(...childPositions.map(p => p.x));
          connections.push(
            <line
              key={`children-line-${person.id}`}
              x1={minChildX}
              y1={dropY}
              x2={maxChildX}
              y2={dropY}
              stroke={isParentHighlighted ? '#f59e0b' : '#64748b'}
              strokeWidth={isParentHighlighted ? 4 : 2}
              strokeLinecap="round"
              style={{
                filter: isParentHighlighted ? 'drop-shadow(0 0 4px rgba(245, 158, 11, 0.6))' : 'none'
              }}
            />
          );
          
          // Vertical lines from horizontal to each child
          childPositions.forEach(childPos => {
            const childTopY = childPos.y - NODE_HEIGHT / 2;
            const isChildHighlighted = selectedPersonId && connectedNodes.has(childPos.person.id);
            
            connections.push(
              <line
                key={`child-conn-${person.id}-${childPos.person.id}`}
                x1={childPos.x}
                y1={dropY}
                x2={childPos.x}
                y2={childTopY}
                stroke={isChildHighlighted || isParentHighlighted ? '#f59e0b' : '#64748b'}
                strokeWidth={isChildHighlighted || isParentHighlighted ? 4 : 2}
                strokeLinecap="round"
                style={{
                  filter: (isChildHighlighted || isParentHighlighted) ? 'drop-shadow(0 0 4px rgba(245, 158, 11, 0.6))' : 'none'
                }}
              />
            );
          });
        }
      }
    }
  });
  
  return (
    <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible">
      {connections}
    </svg>
  );
};

const PersonNode: React.FC<{
  position: NodePosition;
  isSelected: boolean;
  onSelect: () => void;
}> = ({ position, isSelected, onSelect }) => {
  const { person, x, y } = position;
  const age = calculateAge(person.birthDate, person.deathDate);
  const isDeceased = !!person.deathDate;
  const hasChildren = person.childrenIds.length > 0;
  const hasParents = person.parentIds.length > 0;
  
  const genderColors = {
    male: {
      bg: 'from-blue-50 to-indigo-50',
      border: 'border-blue-200',
      ring: 'ring-blue-300',
      accent: 'from-blue-400 to-indigo-500',
      icon: 'bg-blue-100 text-blue-600',
      dot: 'bg-blue-500'
    },
    female: {
      bg: 'from-rose-50 to-pink-50',
      border: 'border-rose-200',
      ring: 'ring-rose-300',
      accent: 'from-rose-400 to-pink-500',
      icon: 'bg-rose-100 text-rose-600',
      dot: 'bg-rose-500'
    },
    other: {
      bg: 'from-violet-50 to-purple-50',
      border: 'border-violet-200',
      ring: 'ring-violet-300',
      accent: 'from-violet-400 to-purple-500',
      icon: 'bg-violet-100 text-violet-600',
      dot: 'bg-violet-500'
    }
  };
  
  const colors = genderColors[person.gender];
  
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3, delay: position.level * 0.08 }}
      className={`absolute cursor-pointer transition-all duration-200 ${
        isSelected ? 'z-50' : 'z-10 hover:z-40'
      }`}
      style={{
        left: x - NODE_WIDTH / 2,
        top: y - NODE_HEIGHT / 2,
        width: NODE_WIDTH,
      }}
      onClick={onSelect}
    >
      {/* Connection dots */}
      {/* Top dot - for parent connection */}
      {hasParents && (
        <div 
          className={`absolute left-1/2 -translate-x-1/2 w-3 h-3 rounded-full ${colors.dot} ring-2 ring-white shadow-sm`}
          style={{ top: '-6px' }}
        />
      )}
      {/* Bottom dot - for children connections */}
      {hasChildren && (
        <div 
          className={`absolute left-1/2 -translate-x-1/2 w-3 h-3 rounded-full ${colors.dot} ring-2 ring-white shadow-sm`}
          style={{ bottom: '-6px' }}
        />
      )}
      {/* Side dot - for spouse connection (only on the right side of the left spouse) */}
      {person.spouseId && (
        <div 
          className="absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-pink-400 ring-2 ring-white shadow-sm z-10"
          style={{ right: '-6px' }}
        />
      )}
      
      <div className={`
        rounded-xl overflow-hidden shadow-md transition-all duration-200 border-2
        ${isSelected 
          ? `ring-4 ${colors.ring} shadow-2xl scale-105 border-transparent` 
          : `hover:shadow-xl hover:scale-[1.02] border-transparent hover:border-opacity-50`
        }
        bg-gradient-to-br ${colors.bg}
      `}>
        <div className="p-3">
          <div className="flex items-center gap-3">
            {/* Avatar */}
            <div className="relative flex-shrink-0">
              <div className={`
                w-14 h-14 rounded-full overflow-hidden ring-2 ring-white shadow-md
                ${isDeceased ? 'grayscale opacity-80' : ''}
              `}>
                {person.photo ? (
                  <img 
                    src={person.photo} 
                    alt={`${person.firstName} ${person.lastName}`}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className={`w-full h-full flex items-center justify-center ${colors.icon}`}>
                    <User className="w-7 h-7" />
                  </div>
                )}
              </div>
              {/* Status indicators */}
              {isDeceased && (
                <div className="absolute -bottom-0.5 -right-0.5 w-4 h-4 bg-gray-600 rounded-full flex items-center justify-center border-2 border-white">
                  <span className="text-[6px] text-white font-bold">†</span>
                </div>
              )}
              {person.spouseId && !isDeceased && (
                <div className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-pink-500 rounded-full flex items-center justify-center border-2 border-white">
                  <Heart className="w-2 h-2 text-white fill-white" />
                </div>
              )}
            </div>
            
            {/* Info */}
            <div className="flex-1 min-w-0">
              <h3 className="font-bold text-gray-900 truncate text-sm leading-tight">
                {person.firstName}
              </h3>
              <h3 className="font-bold text-gray-900 truncate text-sm leading-tight">
                {person.lastName}
              </h3>
              <div className="flex items-center gap-1.5 mt-1">
                <span className="text-xs text-gray-500">
                  {new Date(person.birthDate).getFullYear()}
                </span>
                <span className="text-gray-300">•</span>
                <span className="text-xs text-gray-500">
                  {isDeceased ? `${age} yrs` : `Age ${age}`}
                </span>
              </div>
              {person.occupation && (
                <div className="text-xs text-gray-400 truncate mt-0.5">
                  {person.occupation}
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Bottom accent bar */}
        <div className={`
          h-1.5 w-full bg-gradient-to-r ${colors.accent}
        `} />
      </div>
    </motion.div>
  );
};

const PersonForm: React.FC<{
  person: Person | null;
  onSave: (person: Person) => void;
  onCancel: () => void;
}> = ({ person, onSave, onCancel }) => {
  const [formData, setFormData] = useState<Person>(
    person || {
      id: Date.now().toString(),
      firstName: '',
      lastName: '',
      birthDate: '',
      deathDate: undefined,
      gender: 'other',
      photo: '',
      bio: '',
      occupation: '',
      location: '',
      spouseId: undefined,
      parentIds: [],
      childrenIds: [],
    }
  );
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">First Name</label>
          <input
            type="text"
            value={formData.firstName}
            onChange={e => setFormData({ ...formData, firstName: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">Last Name</label>
          <input
            type="text"
            value={formData.lastName}
            onChange={e => setFormData({ ...formData, lastName: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">Gender</label>
          <select
            value={formData.gender}
            onChange={e => setFormData({ ...formData, gender: e.target.value as 'male' | 'female' | 'other' })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="male">Male</option>
            <option value="female">Female</option>
            <option value="other">Other</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">Photo URL</label>
          <input
            type="url"
            value={formData.photo || ''}
            onChange={e => setFormData({ ...formData, photo: e.target.value })}
            placeholder="https://..."
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">Birth Date</label>
          <input
            type="date"
            value={formData.birthDate}
            onChange={e => setFormData({ ...formData, birthDate: e.target.value })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            required
          />
        </div>
        <div>
          <label className="block text-xs font-medium text-gray-700 mb-1">Death Date</label>
          <input
            type="date"
            value={formData.deathDate || ''}
            onChange={e => setFormData({ ...formData, deathDate: e.target.value || undefined })}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>
      
      <div>
        <label className="block text-xs font-medium text-gray-700 mb-1">Occupation</label>
        <input
          type="text"
          value={formData.occupation || ''}
          onChange={e => setFormData({ ...formData, occupation: e.target.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      
      <div>
        <label className="block text-xs font-medium text-gray-700 mb-1">Location</label>
        <input
          type="text"
          value={formData.location || ''}
          onChange={e => setFormData({ ...formData, location: e.target.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
      
      <div>
        <label className="block text-xs font-medium text-gray-700 mb-1">Bio</label>
        <textarea
          value={formData.bio || ''}
          onChange={e => setFormData({ ...formData, bio: e.target.value })}
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
        />
      </div>
      
      <div className="flex gap-3 pt-4 border-t">
        <button
          type="button"
          onClick={onCancel}
          className="flex-1 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-lg transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="flex-1 px-4 py-2 text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg transition-colors flex items-center justify-center gap-2"
        >
          <Save className="w-4 h-4" />
          Save
        </button>
      </div>
    </form>
  );
};

  // Main App Component
export default function App() {
  const [people, setPeople] = useState<Person[]>(initialFamilyData);
  const [selectedPersonId, setSelectedPersonId] = useState<string | null>(null);
  const [scale, setScale] = useState(0.75);
  const [translate, setTranslate] = useState({ x: 0, y: 100 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [showSidebar, setShowSidebar] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [showPersonModal, setShowPersonModal] = useState(false);
  const [editingPerson, setEditingPerson] = useState<Person | null>(null);
  const [isNewPerson, setIsNewPerson] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const [maximized, setMaximized] = useState(false);
  
  const treeRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Calculate positions
  const positions = useMemo(() => calculateLayout(people), [people]);
  
  // Filter people for search
  const filteredPeople = useMemo(() => {
    if (!searchQuery) return [];
    return people.filter(p => 
      `${p.firstName} ${p.lastName}`.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [people, searchQuery]);
  
  // Statistics
  const stats = useMemo(() => {
    const total = people.length;
    const males = people.filter(p => p.gender === 'male').length;
    const females = people.filter(p => p.gender === 'female').length;
    const others = people.filter(p => p.gender === 'other').length;
    const living = people.filter(p => !p.deathDate).length;
    const deceased = people.filter(p => p.deathDate).length;
    const withChildren = people.filter(p => p.childrenIds.length > 0).length;
    const married = people.filter(p => p.spouseId).length;
    
    return { total, males, females, others, living, deceased, withChildren, married };
  }, [people]);
  
  // Handlers
  const handleZoomIn = () => setScale(s => Math.min(s * 1.2, 3));
  const handleZoomOut = () => setScale(s => Math.max(s / 1.2, 0.3));
  const handleReset = () => {
    setScale(0.75);
    setTranslate({ x: 0, y: 100 });
  };
  
  const handleCenterOnPerson = (personId: string) => {
    const pos = positions.get(personId);
    if (pos && containerRef.current) {
      const containerWidth = containerRef.current.clientWidth;
      const containerHeight = containerRef.current.clientHeight;
      setTranslate({
        x: containerWidth / 2 - pos.x * scale,
        y: containerHeight / 3 - pos.y * scale
      });
      setSelectedPersonId(personId);
    }
  };
  
  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget || (e.target as HTMLElement).closest('.tree-canvas')) {
      setIsDragging(true);
      setDragStart({ x: e.clientX - translate.x, y: e.clientY - translate.y });
    }
  };
  
  const handleMouseMove = useCallback((e: MouseEvent) => {
    if (isDragging) {
      setTranslate({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    }
  }, [isDragging, dragStart]);
  
  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);
  
  useEffect(() => {
    if (isDragging) {
      window.addEventListener('mousemove', handleMouseMove);
      window.addEventListener('mouseup', handleMouseUp);
      return () => {
        window.removeEventListener('mousemove', handleMouseMove);
        window.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, handleMouseMove, handleMouseUp]);
  
  const handleWheel = (e: React.WheelEvent) => {
    if (e.ctrlKey || e.metaKey) {
      e.preventDefault();
      const delta = e.deltaY > 0 ? 0.9 : 1.1;
      setScale(s => Math.max(0.3, Math.min(3, s * delta)));
    }
  };
  
  const handleAddPerson = (type: 'child' | 'spouse' | 'sibling', parentId?: string) => {
    const newPerson: Person = {
      id: Date.now().toString(),
      firstName: 'New',
      lastName: 'Person',
      birthDate: new Date().toISOString().split('T')[0],
      gender: 'other',
      photo: '',
      bio: '',
      occupation: '',
      location: '',
      parentIds: [],
      childrenIds: [],
    };
    
    if (type === 'child' && selectedPersonId) {
      newPerson.parentIds = [selectedPersonId];
      if (people.find(p => p.id === selectedPersonId)?.spouseId) {
        newPerson.parentIds.push(people.find(p => p.id === selectedPersonId)!.spouseId!);
      }
    } else if (type === 'sibling' && parentId) {
      newPerson.parentIds = [parentId];
    }
    
    setEditingPerson(newPerson);
    setIsNewPerson(true);
    setShowPersonModal(true);
  };
  
  const handleSavePerson = (person: Person) => {
    if (isNewPerson) {
      setPeople(prev => {
        const updated = [...prev, person];
        
        // Update parent references
        person.parentIds.forEach(parentId => {
          const parentIndex = updated.findIndex(p => p.id === parentId);
          if (parentIndex !== -1 && !updated[parentIndex].childrenIds.includes(person.id)) {
            updated[parentIndex] = {
              ...updated[parentIndex],
              childrenIds: [...updated[parentIndex].childrenIds, person.id]
            };
          }
        });
        
        return updated;
      });
    } else {
      setPeople(prev => prev.map(p => p.id === person.id ? person : p));
    }
    
    setShowPersonModal(false);
    setEditingPerson(null);
    setIsNewPerson(false);
    setSelectedPersonId(person.id);
  };
  
  const handleDeletePerson = (id: string) => {
    if (confirm('Are you sure you want to delete this person?')) {
      setPeople(prev => {
        // Remove person and update all references
        return prev
          .filter(p => p.id !== id)
          .map(p => ({
            ...p,
            childrenIds: p.childrenIds.filter(cid => cid !== id),
            parentIds: p.parentIds.filter(pid => pid !== id),
            spouseId: p.spouseId === id ? undefined : p.spouseId
          }));
      });
      setSelectedPersonId(null);
    }
  };
  
  const handleExport = async () => {
    if (treeRef.current) {
      try {
        const dataUrl = await htmlToImage.toPng(treeRef.current, {
          backgroundColor: '#f8fafc',
          pixelRatio: 2,
        });
        
        const link = document.createElement('a');
        link.download = `family-tree-${Date.now()}.png`;
        link.href = dataUrl;
        link.click();
      } catch (err) {
        console.error('Export failed:', err);
        alert('Failed to export image');
      }
    }
  };
  
  const handleExportJSON = () => {
    const dataStr = JSON.stringify(people, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.download = `family-tree-${Date.now()}.json`;
    link.href = url;
    link.click();
    URL.revokeObjectURL(url);
  };
  
  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = event => {
        try {
          const imported = JSON.parse(event.target?.result as string);
          if (Array.isArray(imported)) {
            setPeople(imported);
            setSelectedPersonId(null);
          }
        } catch (err) {
          alert('Invalid JSON file');
        }
      };
      reader.readAsText(file);
    }
    e.target.value = '';
  };
  
  const selectedPerson = people.find(p => p.id === selectedPersonId);
  
  return (
    <div className="h-screen w-screen overflow-hidden bg-slate-50 flex">
      {/* Main Canvas Area */}
      <div className="flex-1 relative">
        {/* Toolbar */}
        <div className="absolute top-4 left-4 right-4 z-30 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-white rounded-xl shadow-lg p-2 flex items-center gap-1">
              <button
                onClick={() => setShowSidebar(!showSidebar)}
                className={`p-2 rounded-lg transition-colors ${showSidebar ? 'bg-blue-100 text-blue-600' : 'hover:bg-gray-100'}`}
                title="Toggle Sidebar"
              >
                <Users className="w-5 h-5" />
              </button>
              <div className="w-px h-6 bg-gray-200" />
              <button
                onClick={handleZoomOut}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                title="Zoom Out"
              >
                <ZoomOut className="w-5 h-5" />
              </button>
              <span className="text-sm font-medium text-gray-600 min-w-[60px] text-center">
                {Math.round(scale * 100)}%
              </span>
              <button
                onClick={handleZoomIn}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                title="Zoom In"
              >
                <ZoomIn className="w-5 h-5" />
              </button>
              <button
                onClick={handleReset}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                title="Reset View"
              >
                <RotateCcw className="w-5 h-5" />
              </button>
              <div className="w-px h-6 bg-gray-200" />
              <button
                onClick={() => setMaximized(!maximized)}
                className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                title={maximized ? "Exit Fullscreen" : "Fullscreen"}
              >
                {maximized ? <Minimize2 className="w-5 h-5" /> : <Maximize2 className="w-5 h-5" />}
              </button>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search family..."
                className="pl-10 pr-4 py-2 bg-white rounded-xl shadow-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 w-64"
              />
              {searchQuery && filteredPeople.length > 0 && (
                <div className="absolute top-full mt-2 left-0 right-0 bg-white rounded-xl shadow-xl overflow-hidden max-h-64 overflow-y-auto">
                  {filteredPeople.map(person => (
                    <button
                      key={person.id}
                      onClick={() => {
                        setSearchQuery('');
                        handleCenterOnPerson(person.id);
                      }}
                      className="w-full px-4 py-3 text-left hover:bg-gray-50 flex items-center gap-3"
                    >
                      {person.photo ? (
                        <img src={person.photo} alt="" className="w-8 h-8 rounded-full object-cover" />
                      ) : (
                        <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center">
                          <User className="w-4 h-4 text-gray-500" />
                        </div>
                      )}
                      <div>
                        <div className="font-medium text-sm">{person.firstName} {person.lastName}</div>
                        <div className="text-xs text-gray-500">{formatDate(person.birthDate)}</div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
            
            {/* Stats Button */}
            <button
              onClick={() => setShowStats(!showStats)}
              className={`px-4 py-2 rounded-xl shadow-lg text-sm font-medium transition-colors ${
                showStats ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 hover:bg-gray-50'
              }`}
            >
              Statistics
            </button>
            
            {/* Export Menu */}
            <div className="bg-white rounded-xl shadow-lg p-1 flex items-center">
              <button
                onClick={handleExport}
                className="px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors flex items-center gap-2 text-sm"
              >
                <Download className="w-4 h-4" />
                PNG
              </button>
              <div className="w-px h-4 bg-gray-200" />
              <button
                onClick={handleExportJSON}
                className="px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors flex items-center gap-2 text-sm"
              >
                <Share2 className="w-4 h-4" />
                JSON
              </button>
              <div className="w-px h-4 bg-gray-200" />
              <label className="px-3 py-2 rounded-lg hover:bg-gray-100 transition-colors flex items-center gap-2 text-sm cursor-pointer">
                <Upload className="w-4 h-4" />
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImportJSON}
                  className="hidden"
                />
                Import
              </label>
            </div>
          </div>
        </div>
        
        {/* Helper Text */}
        <div className="absolute bottom-4 left-4 z-20 bg-white/90 backdrop-blur rounded-xl shadow-lg px-4 py-2 text-xs text-gray-500">
          <span className="font-medium">Tip:</span> Drag to pan • Ctrl+Scroll to zoom • Click person for details
        </div>
        
        {/* Statistics Modal */}
        <AnimatePresence>
          {showStats && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="absolute top-20 left-4 z-30 bg-white rounded-2xl shadow-2xl p-6 min-w-[280px]"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold text-gray-900">Family Statistics</h3>
                <button
                  onClick={() => setShowStats(false)}
                  className="p-1 rounded-lg hover:bg-gray-100"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-blue-50 rounded-xl p-3">
                  <div className="text-2xl font-bold text-blue-600">{stats.total}</div>
                  <div className="text-xs text-blue-600/70">Total Members</div>
                </div>
                <div className="bg-green-50 rounded-xl p-3">
                  <div className="text-2xl font-bold text-green-600">{stats.living}</div>
                  <div className="text-xs text-green-600/70">Living</div>
                </div>
                <div className="bg-indigo-50 rounded-xl p-3">
                  <div className="text-2xl font-bold text-indigo-600">{stats.males}</div>
                  <div className="text-xs text-indigo-600/70">Males</div>
                </div>
                <div className="bg-rose-50 rounded-xl p-3">
                  <div className="text-2xl font-bold text-rose-600">{stats.females}</div>
                  <div className="text-xs text-rose-600/70">Females</div>
                </div>
                <div className="bg-amber-50 rounded-xl p-3">
                  <div className="text-2xl font-bold text-amber-600">{stats.withChildren}</div>
                  <div className="text-xs text-amber-600/70">Parents</div>
                </div>
                <div className="bg-purple-50 rounded-xl p-3">
                  <div className="text-2xl font-bold text-purple-600">{stats.married}</div>
                  <div className="text-xs text-purple-600/70">Married</div>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Tree Canvas */}
        <div
          ref={containerRef}
          className={`w-full h-full cursor-grab active:cursor-grabbing ${isDragging ? 'cursor-grabbing' : ''}`}
          onMouseDown={handleMouseDown}
          onWheel={handleWheel}
        >
          {/* Background Grid */}
          <div 
            className="absolute inset-0 pointer-events-none opacity-30"
            style={{
              backgroundImage: `
                linear-gradient(to right, #e2e8f0 1px, transparent 1px),
                linear-gradient(to bottom, #e2e8f0 1px, transparent 1px)
              `,
              backgroundSize: '40px 40px',
              transform: `translate(${translate.x % 40}px, ${translate.y % 40}px)`
            }}
          />
          <div
            ref={treeRef}
            className="tree-canvas origin-top-left"
            style={{
              transform: `translate(${translate.x}px, ${translate.y}px) scale(${scale})`,
              width: '100%',
              height: '100%',
            }}
          >
            {/* Connection Lines */}
            <ConnectionLines 
              positions={positions} 
              selectedPersonId={selectedPersonId}
              connectedNodes={
                selectedPersonId 
                  ? new Set([
                      selectedPersonId,
                      ...(people.find(p => p.id === selectedPersonId)?.parentIds || []),
                      ...(people.find(p => p.id === selectedPersonId)?.childrenIds || []),
                      ...(people.find(p => p.id === selectedPersonId)?.spouseId ? [people.find(p => p.id === selectedPersonId)!.spouseId!] : [])
                    ])
                  : new Set()
              }
            />
            
            {/* Person Nodes */}
            {Array.from(positions.entries()).map(([id, position]) => (
              <PersonNode
                key={id}
                position={position}
                isSelected={selectedPersonId === id}
                onSelect={() => setSelectedPersonId(id)}
              />
            ))}
          </div>
        </div>
        
        {/* Empty State */}
        {people.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <div className="w-24 h-24 bg-gray-200 rounded-full mx-auto mb-4 flex items-center justify-center">
                <Users className="w-12 h-12 text-gray-400" />
              </div>
              <h2 className="text-xl font-semibold text-gray-700 mb-2">No Family Members</h2>
              <p className="text-gray-500 mb-4">Start building your family tree by adding the first person</p>
              <button
                onClick={() => handleAddPerson('child')}
                className="px-6 py-3 bg-blue-600 text-white rounded-xl font-medium hover:bg-blue-700 transition-colors flex items-center gap-2 mx-auto"
              >
                <Plus className="w-5 h-5" />
                Add First Person
              </button>
            </div>
          </div>
        )}
      </div>
      
      {/* Sidebar */}
      <AnimatePresence>
        {showSidebar && (
          <motion.div
            initial={{ x: 400 }}
            animate={{ x: 0 }}
            exit={{ x: 400 }}
            className="w-96 bg-white shadow-2xl border-l border-gray-200 flex flex-col relative z-50"
          >
            {selectedPerson ? (
              <>
                {/* Selected Person Details */}
                <div className="p-6 border-b border-gray-100">
                  <div className="flex items-start gap-4">
                    <div className="relative">
                      <div className={`w-20 h-20 rounded-2xl overflow-hidden ring-4 ${
                        selectedPerson.gender === 'male' ? 'ring-blue-100' : 
                        selectedPerson.gender === 'female' ? 'ring-rose-100' : 'ring-violet-100'
                      }`}>
                        {selectedPerson.photo ? (
                          <img
                            src={selectedPerson.photo}
                            alt={`${selectedPerson.firstName} ${selectedPerson.lastName}`}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className={`w-full h-full flex items-center justify-center ${
                            selectedPerson.gender === 'male' ? 'bg-blue-100 text-blue-600' : 
                            selectedPerson.gender === 'female' ? 'bg-rose-100 text-rose-600' : 
                            'bg-violet-100 text-violet-600'
                          }`}>
                            <User className="w-10 h-10" />
                          </div>
                        )}
                      </div>
                      {selectedPerson.spouseId && (
                        <div className="absolute -top-2 -right-2 w-8 h-8 bg-rose-500 rounded-full flex items-center justify-center shadow-lg">
                          <Heart className="w-4 h-4 text-white fill-white" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1">
                      <h2 className="text-xl font-bold text-gray-900">
                        {selectedPerson.firstName} {selectedPerson.lastName}
                      </h2>
                      <p className="text-sm text-gray-500">
                        {calculateAge(selectedPerson.birthDate, selectedPerson.deathDate)} years old
                        {selectedPerson.deathDate && ' (Deceased)'}
                      </p>
                    </div>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex gap-2 mt-4">
                    <button
                      onClick={() => {
                        setEditingPerson(selectedPerson);
                        setIsNewPerson(false);
                        setShowPersonModal(true);
                      }}
                      className="flex-1 px-3 py-2 bg-blue-50 text-blue-600 rounded-lg text-sm font-medium hover:bg-blue-100 transition-colors flex items-center justify-center gap-2"
                    >
                      <Edit3 className="w-4 h-4" />
                      Edit
                    </button>
                    <button
                      onClick={() => handleAddPerson('child')}
                      className="flex-1 px-3 py-2 bg-green-50 text-green-600 rounded-lg text-sm font-medium hover:bg-green-100 transition-colors flex items-center justify-center gap-2"
                    >
                      <Plus className="w-4 h-4" />
                      Add Child
                    </button>
                    <button
                      onClick={() => handleDeletePerson(selectedPerson.id)}
                      className="px-3 py-2 bg-red-50 text-red-600 rounded-lg text-sm font-medium hover:bg-red-100 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
                
                {/* Details */}
                <div className="flex-1 overflow-y-auto p-6 space-y-6">
                  {/* Dates */}
                  <div>
                    <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
                      <Calendar className="w-4 h-4" />
                      Life Events
                    </h3>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-500">Birth</span>
                        <span className="font-medium">{formatDate(selectedPerson.birthDate)}</span>
                      </div>
                      {selectedPerson.deathDate && (
                        <div className="flex justify-between text-sm">
                          <span className="text-gray-500">Death</span>
                          <span className="font-medium">{formatDate(selectedPerson.deathDate)}</span>
                        </div>
                      )}
                    </div>
                  </div>
                  
                  {/* Occupation & Location */}
                  {(selectedPerson.occupation || selectedPerson.location) && (
                    <div>
                      <h3 className="text-sm font-semibold text-gray-900 mb-3">Professional</h3>
                      <div className="space-y-2">
                        {selectedPerson.occupation && (
                          <div className="flex items-center gap-2 text-sm">
                            <Briefcase className="w-4 h-4 text-gray-400" />
                            <span>{selectedPerson.occupation}</span>
                          </div>
                        )}
                        {selectedPerson.location && (
                          <div className="flex items-center gap-2 text-sm">
                            <MapPin className="w-4 h-4 text-gray-400" />
                            <span>{selectedPerson.location}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                  
                  {/* Bio */}
                  {selectedPerson.bio && (
                    <div>
                      <h3 className="text-sm font-semibold text-gray-900 mb-2">Bio</h3>
                      <p className="text-sm text-gray-600 leading-relaxed">{selectedPerson.bio}</p>
                    </div>
                  )}
                  
                  {/* Family Relations */}
                  <div>
                    <h3 className="text-sm font-semibold text-gray-900 mb-3">Family</h3>
                    
                    {/* Parents */}
                    {selectedPerson.parentIds.length > 0 && (
                      <div className="mb-3">
                        <h4 className="text-xs font-medium text-gray-500 mb-2">Parents</h4>
                        <div className="space-y-2">
                          {selectedPerson.parentIds.map(parentId => {
                            const parent = people.find(p => p.id === parentId);
                            if (!parent) return null;
                            return (
                              <button
                                key={parentId}
                                onClick={() => setSelectedPersonId(parentId)}
                                className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors"
                              >
                                <div className="w-10 h-10 rounded-full overflow-hidden">
                                  {parent.photo ? (
                                    <img src={parent.photo} alt="" className="w-full h-full object-cover" />
                                  ) : (
                                    <div className={`w-full h-full flex items-center justify-center ${
                                      parent.gender === 'male' ? 'bg-blue-100 text-blue-600' : 
                                      parent.gender === 'female' ? 'bg-rose-100 text-rose-600' : 
                                      'bg-violet-100 text-violet-600'
                                    }`}>
                                      <User className="w-5 h-5" />
                                    </div>
                                  )}
                                </div>
                                <div className="text-left">
                                  <div className="text-sm font-medium">{parent.firstName} {parent.lastName}</div>
                                  <div className="text-xs text-gray-500">{parent.occupation}</div>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                    
                    {/* Spouse */}
                    {selectedPerson.spouseId && (
                      <div className="mb-3">
                        <h4 className="text-xs font-medium text-gray-500 mb-2">Spouse</h4>
                        {(() => {
                          const spouse = people.find(p => p.id === selectedPerson.spouseId);
                          if (!spouse) return null;
                          return (
                            <button
                              onClick={() => setSelectedPersonId(spouse.id)}
                              className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors"
                            >
                              <div className="w-10 h-10 rounded-full overflow-hidden">
                                {spouse.photo ? (
                                  <img src={spouse.photo} alt="" className="w-full h-full object-cover" />
                                ) : (
                                  <div className={`w-full h-full flex items-center justify-center ${
                                    spouse.gender === 'male' ? 'bg-blue-100 text-blue-600' : 
                                    spouse.gender === 'female' ? 'bg-rose-100 text-rose-600' : 
                                    'bg-violet-100 text-violet-600'
                                  }`}>
                                    <User className="w-5 h-5" />
                                  </div>
                                )}
                              </div>
                              <div className="text-left">
                                <div className="text-sm font-medium">{spouse.firstName} {spouse.lastName}</div>
                                <div className="text-xs text-gray-500">{spouse.occupation}</div>
                              </div>
                            </button>
                          );
                        })()}
                      </div>
                    )}
                    
                    {/* Children */}
                    {selectedPerson.childrenIds.length > 0 && (
                      <div>
                        <h4 className="text-xs font-medium text-gray-500 mb-2">
                          Children ({selectedPerson.childrenIds.length})
                        </h4>
                        <div className="space-y-2">
                          {selectedPerson.childrenIds.map(childId => {
                            const child = people.find(p => p.id === childId);
                            if (!child) return null;
                            return (
                              <button
                                key={childId}
                                onClick={() => setSelectedPersonId(childId)}
                                className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-gray-50 transition-colors"
                              >
                                <div className="w-10 h-10 rounded-full overflow-hidden">
                                  {child.photo ? (
                                    <img src={child.photo} alt="" className="w-full h-full object-cover" />
                                  ) : (
                                    <div className={`w-full h-full flex items-center justify-center ${
                                      child.gender === 'male' ? 'bg-blue-100 text-blue-600' : 
                                      child.gender === 'female' ? 'bg-rose-100 text-rose-600' : 
                                      'bg-violet-100 text-violet-600'
                                    }`}>
                                      <User className="w-5 h-5" />
                                    </div>
                                  )}
                                </div>
                                <div className="text-left">
                                  <div className="text-sm font-medium">{child.firstName} {child.lastName}</div>
                                  <div className="text-xs text-gray-500">
                                    {calculateAge(child.birthDate)} years old
                                  </div>
                                </div>
                              </button>
                            );
                          })}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center p-6">
                <div className="text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                    <User className="w-8 h-8 text-gray-400" />
                  </div>
                  <p className="text-gray-500">Select a person to view details</p>
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Person Modal */}
      <AnimatePresence>
        {showPersonModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }} 
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/50 backdrop-blur-sm"
              onClick={() => setShowPersonModal(false)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 20 }}
              className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-auto"
            >
              <div className="sticky top-0 bg-white border-b border-gray-100 p-4 flex items-center justify-between">
                <h2 className="text-lg font-bold text-gray-900">
                  {isNewPerson ? 'Add New Person' : 'Edit Person'}
                </h2>
                <button
                  onClick={() => setShowPersonModal(false)}
                  className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-6">
                <PersonForm
                  person={editingPerson}
                  onSave={handleSavePerson}
                  onCancel={() => setShowPersonModal(false)}
                />
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
